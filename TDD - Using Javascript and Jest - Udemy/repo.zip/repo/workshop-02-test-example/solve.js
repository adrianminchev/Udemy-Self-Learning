window.example = {
  hello: name => `Hello ${name}`
}