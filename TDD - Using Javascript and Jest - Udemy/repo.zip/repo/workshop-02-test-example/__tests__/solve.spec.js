require('../solve')

const solve = window.solve
let name

beforeAll(() => {
  name = 'Adrian'
  console.log('I run before all tests')
})

afterAll(() => {
  console.log('I run after all tests have completed')
})

beforeEach(() => {
  console.log('I run before each test')
})

afterEach(() => {
  console.log('I run after each test')
})

describe('solve', () => {

  xtest(`Skipped test`, () => {
    expect(solve.hello(name)).toEqual(`Hello ${name}`)
  })

  test.only('Only test', () => {
    expect(solve.hello()).toEqual('Hello undefined')
  })
})