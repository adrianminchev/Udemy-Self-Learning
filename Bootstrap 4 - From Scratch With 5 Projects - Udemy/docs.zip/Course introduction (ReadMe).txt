Course Introduction:
- Master Bootstrap 4 and build 5 real world themes while learning HTML5 semantics & CSS3

Main points, that are being covered in the course:
- Learn and create amazing high quality Bootstrap 4 themes and UIs from scratch
- Learn the Bootstrap 4 utilities, classes, components & JS widgets using a custom sandbox environment
- Learn semantic HTML5 & modern CSS3 techniques
- Learn to compile Sass in the easiest way possible using a GUI

Direct course URL: https://www.udemy.com/course/bootstrap-4-from-scratch-with-5-projects/