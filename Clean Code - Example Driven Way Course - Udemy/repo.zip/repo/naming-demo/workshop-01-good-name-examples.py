from datetime import datetime


class BlogPost:
    def __init__(self, title, description, date_publisher):
        self.title = title
        self.description = description
        self.date_publisher = date_publisher


def print_blog_post(blog_post):
    print('Title: ' + blog_post.title)
    print('Description: ' + blog_post.description)
    print('Published: ' + blog_post.date_publisher)


title = 'Clean Code Is Great!'
desc = 'Actually, writing Clean Code can be pretty fun. You\'ll see!'
now = datetime.now()
formattedDate = now.strftime('%Y-%m-%d %H:%M')

post = BlogPost(title, desc, formattedDate)

output(post)
