from datetime import datetime


class BlogPost:
    def __init__(self, title, description, date_publisher):
        self.title = title
        self.description = description
        self.date_publisher = date_publisher

    def print(self):
        print('Title: ' + self.title)
        print('Description: ' + self.description)
        print('Published: ' + self.date_publisher)


title = 'Clean Code Is Great!'
description = 'Actually, writing Clean Code can be pretty fun. You\'ll see!'
now = datetime.now()
formattedDate = now.strftime('%Y-%m-%d %H:%M')

blog_post = BlogPost(title, description, formattedDate)

blog_post.print()
